
/*
 * This class will eventually contain the user interface
 */
public class GLLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}
}
