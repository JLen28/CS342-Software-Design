// Joseph Lenaghan | UIN: 676805596 | netID: jlenag2 | 342 project one implementing my own doubly linked list
/*
 * This class will eventually contain the user interface
 */
public class GLLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}
}
